# 晕不晕 · 坐车实测

一个自己玩的小工具：**只有一个模式 —— 真实坐车测试**。点「开始测试」就申请定位并打开全部传感器，一路记录到「结束并导出」，生成 CSV 表格。

- 不登录、不联网、不上传任何数据
- 没有演示模式、没有模拟数据、没有模式切换
- 传感器自检面板：每项都能看到是否在实时出数，卡在哪一步一眼可见
- 全量原始数据存本地，结束时导出 CSV（Excel 双击直接打开）

---

## 一、为什么你在 Chrome 里打开网页，没有 GPS 图标？

**这是浏览器规则，不是代码没调用。**

Chrome 只在**安全上下文**下允许定位 API：

| 打开方式 | 定位能用吗 | GPS 图标 |
|---|---|---|
| `file://`（直接点本地 html 文件） | ❌ 直接禁用 | 不会出现 |
| `http://`（普通 http 链接 / 局域网 IP） | ❌ 直接禁用 | 不会出现 |
| `https://` | ✅ | 会出现 |
| 原生 APK | ✅ | 会出现 |

`file://` 下 Chrome 会立刻返回 `code 1: Only secure origins are allowed`，连授权弹窗都不弹。**任何前端代码都绕不过这个限制**。所以：

> 想要 100% 拿到 GPS，最稳的就是装这个 APK —— 原生 `requestLocationUpdates(GPS_PROVIDER)` 会直接让系统打开 GPS，状态栏定位图标一定出现，跟网页协议无关。

### 让网页也能用 GPS：三步弄出 HTTPS

1. 把 `晕不晕.html` **改名为 `index.html`**（包里已经放了一份现成的 `index.html`）
2. 浏览器打开 **https://app.netlify.com/drop**，把这个文件拖进去，几秒后得到一个 `https://xxx.netlify.app` 网址
3. 手机 Chrome 打开这个网址 → 点「开始测试」→ 弹窗里点「允许」→ 状态栏出现 GPS 图标

也支持 GitHub Pages / Gitee Pages / Vercel / 任意静态托管。

**手机侧还要确认**：系统「位置信息」开关已打开；Chrome 地址栏左侧锁形图标 → 权限 → 位置信息 = 允许；iOS 还需允许「动作与方向访问」。

**自检面板会明确告诉你卡在哪**：协议是不是 https、安全上下文是/否、定位权限状态、最后一条错误原文、GPS 收到几个定位点、每个传感器最后多久前出过数。顶部横幅也会直接写「非 HTTPS 已禁用定位」还是「✅ GPS 已连接」。

---

## 二、怎么打出 APK

环境：Android Studio（Hedgehog 或更新）、JDK 17、Android SDK Platform 34。`minSdk = 29`（Android 10+）。

1. 解压 zip，Android Studio → `File > Open` 选中 `MotionSickness`
2. 等 Gradle Sync 完成（首次需联网拉 Gradle 和 AGP）
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`
4. 产物：`app/build/outputs/apk/debug/app-debug.apk`

命令行（仓库只带 `gradle-wrapper.properties`，需先现场生成 wrapper）：

```bash
cd MotionSickness
gradle wrapper --gradle-version 8.2 --distribution-type bin
chmod +x gradlew && ./gradlew assembleDebug
```

**没有电脑也能出 APK**：只需往 GitHub 仓库放 **2 个文件** —— ① `.github/workflows/build.yml`（内容见 `云编译_复制这段.txt`）② `MotionSickness.zip`（原封不动上传，不要解压）。workflow 会在云端自动 `unzip` 并编译，在 Actions 页点「Run workflow」，5–10 分钟后到 Artifacts 下载 `app-debug.apk`。手机浏览器全程可操作，不用装任何编译软件。详细直达链接见压缩包根目录的 **`怎么装到手机上.md`**。

> 注意：手机网页「Upload files」多选会把文件平铺到根目录、丢掉 `app/` 等目录结构，Gradle 必然失败，所以必须走「传 zip + 云端解压」这条路。

传到手机点安装（允许「未知来源」），或 `adb install -r app/build/outputs/apk/debug/app-debug.apk`。debug 签名，自己装没问题，不能上架。本工程只用系统 API，无第三方库。

---

## 三、它到底调了哪些传感器

| 传感器 | 安卓 API | 用途 |
|---|---|---|
| GPS 定位 | `LocationManager.GPS_PROVIDER` + `ACCESS_FINE_LOCATION` | 车速、经纬度、精度、海拔、航向 |
| 纵向加减速 | GPS 速度微分 | 急刹 / 急加速 |
| 过弯横向 | `速度 × 航向变化率` | 向心加速度、连续弯 |
| 线性加速度 | `TYPE_LINEAR_ACCELERATION` | 三轴已去重力的加速度 |
| 加速度计 | `TYPE_ACCELEROMETER`（无线性加速度时回退，低通扣重力） | 同上 |
| 陀螺仪 | `TYPE_GYROSCOPE` | 角速度 α/β/γ °/s |
| 旋转向量 / 姿态 | `TYPE_ROTATION_VECTOR` / `TYPE_GAME_ROTATION_VECTOR` | 姿态角 α/β/γ |
| 重力 / 地磁 | `TYPE_GRAVITY` / `TYPE_MAGNETIC_FIELD` | 辅助校准 |

网页版对应：`geolocation`（`getCurrentPosition` + `watchPosition`，都在点击的同步调用栈里发起）、`devicemotion`（`acceleration` / `accelerationIncludingGravity` / `rotationRate`）、`deviceorientation`，并优先尝试 Chrome 的 `LinearAccelerationSensor` / `Gyroscope`（通用传感器 API）。

**关键实现**：定位请求写在按钮点击的同步调用栈里，没有被任何 `await` 隔开——这是 Chrome 愿意弹授权、点亮图标的前提。APP 端还会检查 `isProviderEnabled(GPS_PROVIDER)`，系统定位开关没开就直接跳转设置页让你打开。

**摆放**：手机平放固定、屏幕朝上、长边朝车头。GPS 刷新率通常 1–5 Hz，没固定好或航向抖动会带来假的「过弯」。

---

## 四、统计与导出

**采集**：10 Hz，从「开始测试」到「结束并导出」全程记录，每行 25 列：

`序号 / 相对秒 / 时间 / 纬度 / 经度 / 定位精度 / 海拔 / GPS航向 / GPS车速 / 纵向 / 横向 / 垂直 / 加速度XYZ / 陀螺αβγ / 姿态αβγ / 晕车概率 / 档位 / MSDV / 事件标记`

事件标记会自动打上 `急刹 / 急加速 / 强弯 / 颠簸 / 定位丢失`。

**结束时的汇总块**（附在 CSV 末尾）：时长、采样点、GPS 定位点数、最高/平均车速、三轴最大加速度、急刹/急加速/强弯/颠簸次数、平均/峰值晕车概率、峰值 MSDV、四档占比。

**存储与导出**：
- 网页版：CSV 自动下载，同时把最近 8 次行程存进浏览器 localStorage，页面底部「历史行程」可重新下载或删除
- APP 版：CSV 写进系统「下载」目录（MediaStore.Downloads，UTF-8 BOM，Excel 不乱码），同时备份到应用内部 `files/trips/`，并弹出分享面板
- 界面上实时显示：时长、采样点、平均概率、峰值概率、急刹次数、强弯次数

---

## 五、数值依据

**① 感觉冲突 / 神经失配**：Reason & Brand (1975)、Reason (1978)——视觉、前庭、本体觉对不上就晕。

**② 0.1–0.5 Hz 慢晃最致晕**：Golding & Gresty (2016) 指出 0.2–0.3 Hz 最猛，大脑分不清「平移」还是「倾斜」；高于 1 Hz 基本不诱发。

**③ 剂量累积**：ISO 2631-1 (1997) 的 Wf 加权、`MSDV = √(∫ a_w² dt)`、`MSI = K_m · MSDV`（未适应混合成人 `K_m ≈ 1/3`）。本工具用「0.1 Hz 高通 + 0.5 Hz 低通」近似 Wf，三轴加权，横向权重更高。

**④ 横向更致晕**：实车实验里 S 弯 > 急停急起 > 直线加减速 > 单向转弯；0.4 g @ 0.2 Hz 连续侧晃 30 分钟是经典致晕条件；只看车内视野比看窗外明显更难受。

**⑤ 阈值（自定，别当标准）**：纵向 3.0 m/s² ≈ 0.3 g 算急刹满分，横向 4.0 m/s² ≈ 0.4 g 算强弯满分。瞬时项 0.62（急刹 0.30 / 过弯 0.45 / 低频晃动 0.25），剂量项 0.38 用 `1 − exp(−Km·MSDV·0.35)`，停车后剂量按 45 s 时间常数衰减。

档位：<25% 稳得住 / 25–50% 有点晃 / 50–75% 该看窗外了 / >75% 快到极限了。

---

## 六、它不准在哪

- 自玩 demo，**不是医学判断**，别拿它决定要不要吃药、能不能开车。
- ISO 2631-1 原本为船舶垂直振动而建，对汽车水平运动适用性有争议；MSDV 在停走拥堵、个体适应性上预测力波动很大（元分析里 R² 从 0.79 到 0.027 都出现过）。
- 晕不晕还受睡眠、饱腹、看没看手机、坐前排后排、个人易感性影响，这些一个都没测。
- 概率只是把「晃得猛不猛 + 晃了多久」映射到 0–100 的直观刻度，没有人群统计标定。

---

## 七、文件结构

```
MotionSickness/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── README.md
├── index.html                                  ← 直接拖到 Netlify Drop 就能出 HTTPS
├── 晕不晕.html                                  ← 网页版（同一份内容）
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml                  定位权限（仅精确定位 + 粗略定位）
        ├── java/com/yuanbao/carsick/
        │   ├── MainActivity.kt                 权限/GPS开关检查、采集调度、自检面板、CSV导出
        │   ├── SensorHub.kt                     GPS + 7 类运动传感器
        │   ├── MotionSicknessEstimator.kt      概率算法（与网页版同一套）
        │   ├── TripRecorder.kt                 全量记录 + 汇总 + CSV 生成
        │   └── DialView.kt                     环形进度
        └── res/                                布局 / 颜色 / 主题
```
