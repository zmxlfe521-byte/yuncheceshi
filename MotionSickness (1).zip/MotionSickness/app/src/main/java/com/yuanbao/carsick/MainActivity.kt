package com.yuanbao.carsick

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var hub: SensorHub
    private val est = MotionSicknessEstimator()
    private val trip = TripRecorder()
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var lastTick = 0L
    private var lastSensorRender = 0L

    private lateinit var dial: DialView
    private lateinit var tvProb: TextView
    private lateinit var tvLevel: TextView
    private lateinit var tvTip: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var tvSpeedDesc: TextView
    private lateinit var tvLong: TextView
    private lateinit var tvLongDesc: TextView
    private lateinit var tvLat: TextView
    private lateinit var tvLatDesc: TextView
    private lateinit var tvVert: TextView
    private lateinit var tvVertDesc: TextView
    private lateinit var tvDose: TextView
    private lateinit var pbDose: ProgressBar
    private lateinit var sensorBox: LinearLayout
    private lateinit var tvSensorSummary: TextView
    private lateinit var tvDiag: TextView
    private lateinit var tvStatus: TextView
    private lateinit var sDur: TextView
    private lateinit var sN: TextView
    private lateinit var sAvg: TextView
    private lateinit var sMax: TextView
    private lateinit var sBrake: TextView
    private lateinit var sTurn: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnReset: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        hub = SensorHub(this)

        dial = findViewById(R.id.dial)
        tvProb = findViewById(R.id.tvProb); tvLevel = findViewById(R.id.tvLevel); tvTip = findViewById(R.id.tvTip)
        tvSpeed = findViewById(R.id.tvSpeed); tvSpeedDesc = findViewById(R.id.tvSpeedDesc)
        tvLong = findViewById(R.id.tvLong); tvLongDesc = findViewById(R.id.tvLongDesc)
        tvLat = findViewById(R.id.tvLat); tvLatDesc = findViewById(R.id.tvLatDesc)
        tvVert = findViewById(R.id.tvVert); tvVertDesc = findViewById(R.id.tvVertDesc)
        tvDose = findViewById(R.id.tvDose); pbDose = findViewById(R.id.pbDose)
        sensorBox = findViewById(R.id.sensorBox)
        tvSensorSummary = findViewById(R.id.tvSensorSummary); tvDiag = findViewById(R.id.tvDiag)
        tvStatus = findViewById(R.id.tvStatus)
        sDur = findViewById(R.id.sDur); sN = findViewById(R.id.sN); sAvg = findViewById(R.id.sAvg)
        sMax = findViewById(R.id.sMax); sBrake = findViewById(R.id.sBrake); sTurn = findViewById(R.id.sTurn)
        btnStart = findViewById(R.id.btnStart); btnStop = findViewById(R.id.btnStop); btnReset = findViewById(R.id.btnReset)

        btnStart.setOnClickListener { startTest() }
        btnStop.setOnClickListener { finishTest() }
        btnReset.setOnClickListener {
            if (running) { running = false; handler.removeCallbacks(ticker); hub.stopAll() }
            trip.start()                // 清空当次记录
            est.reset()
            btnStart.isEnabled = true; btnStop.isEnabled = false
            render(est.update(0.0, 0.0, 0.0, 0.0, 0.05))
            renderSensors(); setStatus("已重置（已导出的 CSV 仍保留在下载目录）")
        }

        render(est.update(0.0, 0.0, 0.0, 0.0, 0.05))
        renderSensors()
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        handler.removeCallbacks(ticker)
        hub.stopAll()
    }

    /** 权限 → 系统定位开关 → 真正启动 GPS 与全部传感器 */
    private fun startTest() {
        if (running) return
        if (!hub.hasLocationPermission()) {
            setStatus("正在申请定位权限…")
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }
        if (!hub.isGpsProviderEnabled()) {
            setStatus("系统「位置信息」开关没打开，已跳转到设置，打开后回来再点开始")
            try { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (e: Exception) { }
            return
        }
        hub.resetTripState()
        hub.startSensors()
        hub.startGps()                 // ← 这一步会让状态栏出现 GPS 图标
        trip.start()
        est.reset()
        running = true
        lastTick = System.currentTimeMillis()
        btnStart.isEnabled = false; btnStop.isEnabled = true
        handler.removeCallbacks(ticker); handler.post(ticker)
        setStatus("采集中 · 10 Hz 记录全部原始数据 · 点「结束并导出」生成 CSV")
        renderSensors()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startTest()
        } else {
            setStatus("定位权限被拒绝：设置 → 应用 → 晕不晕 → 权限 → 允许位置信息")
        }
    }

    private fun finishTest() {
        running = false
        handler.removeCallbacks(ticker)
        hub.stopAll()
        btnStart.isEnabled = true; btnStop.isEnabled = false
        if (trip.n == 0) { setStatus("本次没有采集到数据，未生成文件"); renderSensors(); return }
        val csv = trip.buildCsv()
        val name = trip.fileName()
        val saved = exportCsv(csv, name)
        setStatus(
            if (saved) "已结束 · ${trip.n} 条数据 · CSV 已存到「下载」目录并弹出分享"
            else "已结束 · ${trip.n} 条数据 · 已存到应用内部目录（${filesDir}/trips）"
        )
        renderSensors()
    }

    /** 写 Downloads（系统下载目录）+ 应用内部备份，再弹出分享 */
    private fun exportCsv(csv: String, name: String): Boolean {
        try {
            val dir = File(filesDir, "trips"); dir.mkdirs()
            File(dir, "$name.csv").writeText(csv, Charsets.UTF_8)
        } catch (e: Exception) { /* 备份失败不影响主流程 */ }

        return try {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "$name.csv")
                put(MediaStore.Downloads.MIME_TYPE, "text/csv")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return false
            contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
            cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(uri, cv, null, null)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "导出行程 CSV"))
            true
        } catch (e: Exception) { false }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            val now = System.currentTimeMillis()
            val dt = ((now - lastTick) / 1000.0).coerceIn(0.001, 0.25)
            lastTick = now

            // GPS 超过 5s 没新点视为信号中断
            if (hub.gpsOk && now - hub.lastSensorAt > 5000) hub.gpsOk = false
            val r = est.update(hub.aLong, hub.aLat, hub.aZ, hub.speedKmh, dt)
            trip.add(
                TripRecorder.Snapshot(
                    hub.lat, hub.lon, hub.accM, hub.altM, hub.bearingDeg, hub.speedKmh,
                    hub.aLong, hub.aLat, hub.aZ,
                    hub.aX, hub.aY, hub.aZ,
                    hub.gX, hub.gY, hub.gZ,
                    hub.oA, hub.oB, hub.oG,
                    r.prob, r.level, r.msdv, hub.gpsOk
                )
            )
            render(r)
            if (now - lastSensorRender > 800) { renderSensors(); lastSensorRender = now }
            handler.postDelayed(this, 100L)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun renderSensors() {
        sensorBox.removeAllViews()
        var ok = 0
        val now = System.currentTimeMillis()
        hub.sensorNames.forEach { (name, on) ->
            if (on) ok++
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(3), 0, dp(3))
            }
            val dot = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(8) }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (on) Color.parseColor("#0FA98F") else Color.parseColor("#C9D4D1"))
                }
            }
            val nm = TextView(this).apply {
                text = name; textSize = 12f
                setTextColor(Color.parseColor("#16211F"))
                layoutParams = LinearLayout.LayoutParams(dp(92), LinearLayout.LayoutParams.WRAP_CONTENT)
            }
            val value = sensorValue(name, on, now)
            val vl = TextView(this).apply {
                text = value; textSize = 11f
                setTextColor(Color.parseColor("#7B8A87"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                maxLines = 1
            }
            row.addView(dot); row.addView(nm); row.addView(vl)
            sensorBox.addView(row)
        }
        tvSensorSummary.text = "$ok / ${hub.sensorNames.size} 就绪"
        tvDiag.text = buildString {
            append("定位权限: ").append(if (hub.hasLocationPermission()) "已允许" else "未允许").append('\n')
            append("系统定位开关: ").append(if (hub.isGpsProviderEnabled()) "已打开" else "已关闭").append('\n')
            append("GPS 定位点: ").append(hub.gpsFix).append(" 次  |  车速 ").append(String.format(Locale.US, "%.0f", hub.speedKmh)).append(" km/h").append('\n')
            append("最后传感器数据: ").append(
                if (hub.lastSensorAt == 0L) "—" else ((now - hub.lastSensorAt) / 1000).toString() + "s 前"
            ).append('\n')
            append("采样: 10 Hz · 原始数据全量写入 CSV")
        }
    }

    private fun sensorValue(name: String, on: Boolean, now: Long): String = when {
        !on -> "未就绪"
        name == "GPS 定位" -> {
            val p = if (hub.lat != null) String.format(Locale.US, "%.4f, %.4f", hub.lat, hub.lon) else "搜星中"
            "$p · ${String.format(Locale.US, "%.0f", hub.speedKmh)}km/h · ±${hub.accM?.toInt() ?: 0}m"
        }
        name == "陀螺仪" -> String.format(Locale.US, "α%.1f β%.1f γ%.1f °/s", hub.gX, hub.gY, hub.gZ)
        name == "旋转向量/姿态" -> String.format(Locale.US, "α%.0f β%.0f γ%.0f °", hub.oA ?: 0.0, hub.oB ?: 0.0, hub.oG ?: 0.0)
        name == "线性加速度" || name == "加速度计" -> String.format(Locale.US, "x%.2f y%.2f z%.2f", hub.aX, hub.aY, hub.aZ)
        else -> "已注册 · ${if (now - hub.lastSensorAt < 2000) "实时出数" else "待数据"}"
    }

    private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)
    private fun signed(x: Double) = (if (x >= 0) "+" else "") + f1(x)

    private fun render(r: Estimate) {
        val c = Color.parseColor(r.colorHex)
        dial.set(r.prob.toFloat(), c)
        tvProb.text = "${r.prob.roundToInt()}%"
        tvLevel.text = if (running) r.level else "待开始"
        tvLevel.setTextColor(c)
        val bg = tvLevel.background?.mutate()
        if (bg is GradientDrawable) bg.setColor(Color.argb(34, Color.red(c), Color.green(c), Color.blue(c)))
        tvTip.text = when {
            !running -> "点「开始测试」，会申请定位并打开全部传感器"
            !hub.gpsOk -> "正在搜 GPS 信号，请确认系统定位已打开"
            else -> r.tip
        }

        tvSpeed.text = r.speed.roundToInt().toString()
        tvSpeedDesc.text = if (!hub.gpsOk) "无定位" else when {
            r.speed < 1.5 -> "静止"; r.speed < 30 -> "市区"; r.speed < 80 -> "快速路"; else -> "高速"
        }
        tvLong.text = signed(r.aLong)
        tvLongDesc.text = when {
            r.aLong > 1.2 -> "急加速"; r.aLong < -1.2 -> "急刹车"; abs(r.aLong) > 0.5 -> "在变速"; else -> "平稳"
        }
        tvLat.text = f1(abs(r.aLat))
        tvLatDesc.text = when {
            abs(r.aLat) > 3 -> "急弯"; abs(r.aLat) > 1.5 -> "连续弯"; abs(r.aLat) > 0.5 -> "缓弯"; else -> "直路"
        }
        tvVert.text = f1(r.aVert)
        tvVertDesc.text = when {
            abs(r.aVert) > 2 -> "明显颠簸"; abs(r.aVert) > 0.8 -> "轻微颠簸"; else -> "平顺"
        }
        tvDose.text = String.format(Locale.US, "%.2f m/s^1.5", r.msdv)
        pbDose.progress = (r.msdv / 25.0 * 100.0).roundToInt().coerceIn(0, 100)
        pbDose.progressTintList = ColorStateList.valueOf(c)

        sDur.text = if (trip.durS < 60) "${trip.durS.toInt()}s" else String.format(Locale.US, "%.1fmin", trip.durS / 60.0)
        sN.text = trip.n.toString()
        sAvg.text = "${trip.avgProb.roundToInt()}%"
        sMax.text = "${trip.maxProb.roundToInt()}%"
        sBrake.text = trip.brake.toString()
        sTurn.text = trip.sharpTurn.toString()
    }

    private fun setStatus(s: String) { tvStatus.text = s }
}
