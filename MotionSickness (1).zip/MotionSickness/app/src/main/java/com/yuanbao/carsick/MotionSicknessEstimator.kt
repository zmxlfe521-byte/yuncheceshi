package com.yuanbao.carsick

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sqrt

/**
 * 晕车概率估计器（娱乐向，非医学判断）
 *
 * 依据：
 *  - Reason & Brand (1975) / Reason (1978)：感觉冲突与神经失配理论
 *  - Golding & Gresty (2016)：0.2–0.3 Hz 线性振荡最易致晕，tilt-translation 歧义
 *  - 神经生理综述：0.1–0.5 Hz 慢晃比高频更易引发恶心
 *  - ISO 2631-1 (1997)：Wf 频率加权、MSDV = sqrt(∫a_w²dt)、MSI = Km·MSDV（Km≈1/3）
 *  - 实车研究：S 弯 / 连续横向加速度 > 急停急起 > 直线加减速；0.4 g @ 0.2 Hz 为经典致晕条件
 *
 * 实现上用「0.1 Hz 高通 + 0.5 Hz 低通」近似 Wf 带通，
 * 把纵向/横向/垂直三轴加权后按时间累积成剂量，再叠加瞬时急刹、过弯、低频晃动。
 */
data class Estimate(
    val prob: Double,
    val level: String,
    val colorHex: String,
    val tip: String,
    val msdv: Double,
    val speed: Double,
    val aLong: Double,
    val aLat: Double,
    val shake: Double
)

class MotionSicknessEstimator {

    private class State(var y: Double = 0.0, var prev: Double = 0.0) {
        fun reset() { y = 0.0; prev = 0.0 }
    }
    private class Band {
        val h = State()
        val l = State()
        fun reset() { h.reset(); l.reset() }
    }

    companion object {
        private const val FC_HP = 0.10          // Wf 敏感带下界
        private const val FC_LP = 0.50          // Wf 敏感带上界
        private const val BP_GAIN = 1.20        // 0.2 Hz 附近增益归一
        private const val K_LONG = 0.90
        private const val K_LAT = 1.25          // 横向权重更高
        private const val K_VERT = 0.80
        private const val KM = 1.0 / 3.0        // ISO 2631-1 未适应成人群体系数
        private const val DOSE_SCALE = 0.35
        private const val SHOCK_REF = 3.0       // m/s²，约 0.3 g 急刹满分
        private const val TURN_REF = 4.0        // m/s²，约 0.4 g 强弯满分
        private const val OSC_REF = 1.2
        private const val SHAKE_REF = 2.5        // 手持晃动满分参考
        private const val W_INSTANT = 0.62
        private const val W_DOSE = 0.38
    }

    private var msdv2 = 0.0
    private var env = 0.0
    private val bL = Band()
    private val bT = Band()
    private val bV = Band()
    private val envState = State()

    fun reset() {
        msdv2 = 0.0; env = 0.0
        bL.reset(); bT.reset(); bV.reset(); envState.reset()
    }

    private fun hp(x: Double, s: State, dt: Double, fc: Double): Double {
        val rc = 1.0 / (2.0 * PI * fc)
        val a = rc / (rc + dt)
        val y = a * (s.y + x - s.prev)
        s.prev = x; s.y = y
        return y
    }
    private fun lp(x: Double, s: State, dt: Double, fc: Double): Double {
        val rc = 1.0 / (2.0 * PI * fc)
        val a = dt / (rc + dt)
        s.y += a * (x - s.y)
        return s.y
    }
    private fun band(x: Double, b: Band, dt: Double): Double =
        lp(hp(x, b.h, dt, FC_HP), b.l, dt, FC_LP) * BP_GAIN

    fun update(
        aLongIn: Double,
        aLatIn: Double,
        aVertIn: Double,
        speedIn: Double,
        dtRaw: Double,
        shakeIn: Double = 0.0
    ): Estimate {
        val dt = dtRaw.coerceIn(0.001, 0.25)

        // ① 近似 Wf 带通，只保留 0.1–0.5 Hz 的「慢晃」
        val wL = band(aLongIn, bL, dt)
        val wT = band(aLatIn, bT, dt)
        val wV = band(aVertIn, bV, dt)
        val aw2 = K_LONG * wL * wL + K_LAT * wT * wT + K_VERT * wV * wV
        val aw = sqrt(aw2)
        val shakeN = (shakeIn / SHAKE_REF).coerceIn(0.0, 1.0)

        // ② MSDV² = ∫ a_w² dt（ISO 2631-1 剂量累积）；手持晃动另给一点等效剂量
        msdv2 += (aw2 + 0.35 * shakeN * shakeN) * dt
        env = lp(aw * aw, envState, dt, 0.30)
        val rms = sqrt(max(0.0, env))
        val msdv = sqrt(msdv2)

        // ③ 瞬时刺激：急刹 / 强弯 / 低频晃动 / 手持晃动
        val shock = (abs(aLongIn) / SHOCK_REF).coerceIn(0.0, 1.0)
        val turn = (abs(aLatIn) / TURN_REF).coerceIn(0.0, 1.0)
        val osc = (rms / OSC_REF).coerceIn(0.0, 1.0)
        val instant = 100.0 * (0.24 * shock + 0.34 * turn + 0.18 * osc + 0.24 * shakeN)

        // ④ 剂量项：MSI = Km·MSDV，用指数压到 0–100%
        val doseP = 100.0 * (1.0 - exp(-KM * msdv * DOSE_SCALE))

        var p = W_INSTANT * instant + W_DOSE * doseP
        if (speedIn < 1.5) {
            p *= 0.80
            msdv2 *= exp(-dt / 45.0)   // 停车后缓慢恢复
        }
        p = p.coerceIn(0.0, 99.0)

        val (level, color) = when {
            p < 25 -> "稳得住" to "#0FA98F"
            p < 50 -> "有点晃" to "#8BC34A"
            p < 75 -> "该看窗外了" to "#F0A531"
            else -> "快到极限了" to "#EE5B52"
        }

        val tip = when {
            speedIn < 1.5 -> "车停着，缓一会儿就好"
            shakeN > 0.5 -> "你在晃手机，相当于把手机当车在晃"
            turn > 0.55 -> "连续弯道，横向晃得最磨人"
            shock > 0.55 -> "刹车/给油有点猛，脑袋跟着点"
            rms > 0.8 -> "低频慢晃，正是最容易晕的节奏"
            p > 55 -> "晃太久了，抬头看看远处"
            else -> "开得挺稳，基本没事"
        }

        return Estimate(p, level, color, tip, msdv, speedIn, aLongIn, aLatIn, shakeIn)
    }
}
