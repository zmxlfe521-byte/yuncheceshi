package com.yuanbao.carsick

import java.util.Locale

/** 一次行程的全量原始数据 + 汇总统计 + CSV */
class TripRecorder {

    data class Snapshot(
        val lat: Double?, val lon: Double?, val accM: Float?, val altM: Double?,
        val bearing: Float?, val speedKmh: Double,
        val aLong: Double, val aLat: Double, val aVert: Double,
        val ax: Double, val ay: Double, val az: Double,
        val gx: Double, val gy: Double, val gz: Double,
        val oa: Double?, val ob: Double?, val og: Double?,
        val prob: Double, val level: String, val msdv: Double,
        val gpsOk: Boolean
    )

    private val rows = mutableListOf<Array<String>>()
    var startAt = 0L
        private set
    var n = 0
        private set
    var durS = 0.0
        private set
    var sumProb = 0.0; var maxProb = 0.0; var peakMsdv = 0.0
    var maxLong = 0.0; var maxLat = 0.0; var maxVert = 0.0
    var brake = 0; var accel = 0; var sharpTurn = 0; var bump = 0
    var maxV = 0.0; var sumV = 0.0; var vN = 0
    var gpsFix = 0
    val levels = intArrayOf(0, 0, 0, 0)
    private var lastBrake = -99.0; private var lastTurn = -99.0; private var lastBump = -99.0

    companion object {
        val HEAD = arrayOf(
            "序号", "相对秒", "时间", "纬度", "经度", "定位精度m", "海拔m", "GPS航向°", "GPS车速km/h",
            "纵向m/s²", "横向m/s²", "垂直m/s²", "加速度X", "加速度Y", "加速度Z",
            "陀螺α°/s", "陀螺β°/s", "陀螺γ°/s", "姿态α", "姿态β", "姿态γ",
            "晕车概率%", "档位", "MSDV", "事件"
        )
        private val SIMPLE_TIME = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        private val FILE_TIME = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
    }

    fun start() {
        rows.clear(); startAt = System.currentTimeMillis(); n = 0; durS = 0.0
        sumProb = 0.0; maxProb = 0.0; peakMsdv = 0.0
        maxLong = 0.0; maxLat = 0.0; maxVert = 0.0
        brake = 0; accel = 0; sharpTurn = 0; bump = 0
        maxV = 0.0; sumV = 0.0; vN = 0; gpsFix = 0
        for (i in 0..3) levels[i] = 0
        lastBrake = -99.0; lastTurn = -99.0; lastBump = -99.0
    }

    private fun f(v: Double, d: Int = 3) = String.format(Locale.US, "%.${d}f", v)

    fun add(s: Snapshot) {
        val t = (System.currentTimeMillis() - startAt) / 1000.0
        durS = t; n++
        val ev = mutableListOf<String>()
        if (s.aLong < -2.5 && t - lastBrake > .8) { brake++; lastBrake = t; ev.add("急刹") }
        if (s.aLong > 2.5 && t - lastBrake > .8) { accel++; lastBrake = t; ev.add("急加速") }
        if (kotlin.math.abs(s.aLat) > 3 && t - lastTurn > .8) { sharpTurn++; lastTurn = t; ev.add("强弯") }
        if (kotlin.math.abs(s.aVert) > 2 && t - lastBump > .6) { bump++; lastBump = t; ev.add("颠簸") }
        if (!s.gpsOk) ev.add("定位丢失")
        if (s.gpsOk) gpsFix++

        sumProb += s.prob; maxProb = maxOf(maxProb, s.prob); peakMsdv = maxOf(peakMsdv, s.msdv)
        maxLong = maxOf(maxLong, kotlin.math.abs(s.aLong))
        maxLat = maxOf(maxLat, kotlin.math.abs(s.aLat))
        maxVert = maxOf(maxVert, kotlin.math.abs(s.aVert))
        maxV = maxOf(maxV, s.speedKmh)
        if (s.speedKmh > 1) { sumV += s.speedKmh; vN++ }
        levelIndex(s.prob).let { levels[it]++ }

        rows.add(arrayOf(
            n.toString(), f(t, 2), SIMPLE_TIME.format(System.currentTimeMillis()),
            s.lat?.let { f(it, 6) } ?: "", s.lon?.let { f(it, 6) } ?: "",
            s.accM?.let { f(it.toDouble(), 1) } ?: "", s.altM?.let { f(it, 1) } ?: "",
            s.bearing?.let { f(it.toDouble(), 1) } ?: "", f(s.speedKmh, 1),
            f(s.aLong), f(s.aLat), f(s.aVert),
            f(s.ax), f(s.ay), f(s.az),
            f(s.gx, 2), f(s.gy, 2), f(s.gz, 2),
            s.oa?.let { f(it, 1) } ?: "", s.ob?.let { f(it, 1) } ?: "", s.og?.let { f(it, 1) } ?: "",
            f(s.prob, 1), s.level, f(s.msdv), ev.joinToString("/")
        ))
    }

    private fun levelIndex(p: Double) = when { p < 25 -> 0; p < 50 -> 1; p < 75 -> 2; else -> 3 }

    private fun cell(v: String): String =
        if (v.contains(',') || v.contains('"') || v.contains('\n')) "\"" + v.replace("\"", "\"\"") + "\"" else v
    private fun line(a: Array<String>) = a.joinToString(",") { cell(it) }
    private fun line(s: String, v: Any) = cell(s) + "," + cell(v.toString())

    val avgProb: Double get() = if (n > 0) sumProb / n else 0.0
    val avgV: Double get() = if (vN > 0) sumV / vN else 0.0

    fun fileName(): String = "晕不晕_" + FILE_TIME.format(startAt)

    /** UTF-8 BOM 开头，Excel 双击直接打开不乱码 */
    fun buildCsv(): String {
        val sb = StringBuilder("\uFEFF")
        sb.append(line("# 晕不晕 · 坐车实测数据")).append('\n')
        sb.append(line("# 开始", SIMPLE_TIME.format(startAt))).append('\n')
        sb.append(line("# 结束", SIMPLE_TIME.format(System.currentTimeMillis()))).append('\n')
        sb.append(line("# 时长s", f(durS, 1))).append('\n')
        sb.append(line("# 采样点", n)).append('\n')
        sb.append(line("# GPS定位点", gpsFix)).append('\n')
        sb.append(line("# 来源", "GPS + 加速度计 + 线性加速度 + 陀螺仪 + 旋转向量")).append('\n')
        sb.append('\n')
        sb.append(line(HEAD)).append('\n')
        rows.forEach { sb.append(line(it)).append('\n') }
        sb.append('\n').append(line("# 汇总")).append('\n')
        sb.append(line("指标", "值")).append('\n')
        listOf(
            "时长s" to f(durS, 1), "采样点" to n, "GPS定位点数" to gpsFix,
            "最高车速km/h" to f(maxV, 1), "平均车速km/h" to f(avgV, 1),
            "最大纵向加速度m/s2" to f(maxLong, 2), "最大横向加速度m/s2" to f(maxLat, 2),
            "最大垂直加速度m/s2" to f(maxVert, 2),
            "急刹次数" to brake, "急加速次数" to accel, "强弯次数" to sharpTurn, "颠簸次数" to bump,
            "平均晕车概率%" to f(avgProb, 1), "峰值晕车概率%" to f(maxProb, 1), "峰值MSDV" to f(peakMsdv, 2),
            "稳得住占比%" to f(pct(0), 1), "有点晃占比%" to f(pct(1), 1),
            "该看窗外占比%" to f(pct(2), 1), "快到极限占比%" to f(pct(3), 1)
        ).forEach { sb.append(line(it.first, it.second)).append('\n') }
        return sb.toString()
    }

    private fun pct(i: Int) = if (n > 0) levels[i].toDouble() / n * 100.0 else 0.0
}
