package com.yuanbao.carsick

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/** 极简环形进度表盘 */
class DialView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var progress = 0f
    private var barColor = Color.parseColor("#0FA98F")
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 14f
    }

    fun set(prob: Float, color: Int) {
        progress = prob.coerceIn(0f, 100f)
        barColor = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val c = min(width, height) / 2f
        val r = c - 14f
        paint.color = Color.parseColor("#EEF3F1")
        canvas.drawCircle(c, c, r, paint)
        if (progress > 0.5f) {
            paint.color = barColor
            canvas.drawArc(c - r, c - r, c + r, c + r, -90f, 360f * progress / 100f, false, paint)
        }
    }
}
