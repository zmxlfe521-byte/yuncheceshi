package com.yuanbao.carsick

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import kotlin.math.PI

/**
 * 真实传感器采集：GPS + 加速度计 + 线性加速度 + 陀螺仪 + 旋转向量 + 重力 + 地磁。
 *
 * 关键：requestLocationUpdates(GPS_PROVIDER, ...) 一旦注册，系统就会真正打开 GPS
 * 并在状态栏点亮定位图标 —— 这是原生 APP 不受网页 HTTPS 限制的根本原因。
 *
 * 摆放假设：手机平放固定、屏幕朝上、长边朝车头（x≈横向，y≈纵向，z≈垂直）。
 */
class SensorHub(private val ctx: Context) : SensorEventListener, LocationListener {

    // 加速度（已去重力）
    var aX = 0.0; var aY = 0.0; var aZ = 0.0
    // 陀螺仪 °/s
    var gX = 0.0; var gY = 0.0; var gZ = 0.0
    // 姿态 °
    var oA: Double? = null; var oB: Double? = null; var oG: Double? = null
    // GPS
    var lat: Double? = null; var lon: Double? = null; var accM: Float? = null
    var altM: Double? = null; var bearingDeg: Float? = null
    var speedKmh = 0.0; var gpsFix = 0; var gpsOk = false
    // 由 GPS 推导
    var aLong = 0.0; var aLat = 0.0

    val sensorNames = linkedMapOf(
        "GPS 定位" to false,
        "线性加速度" to false,
        "加速度计" to false,
        "陀螺仪" to false,
        "旋转向量/姿态" to false,
        "重力传感器" to false,
        "地磁传感器" to false
    )
    var lastSensorAt = 0L
        private set
    var sensorsRunning = false
        private set
    var gpsRunning = false
        private set

    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val gravity = FloatArray(3)
    private val rotMat = FloatArray(9)
    private val orient = FloatArray(3)
    private var prevV = 0.0
    private var prevT = 0.0
    private var prevBearing: Double? = null

    fun hasLocationPermission(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun isGpsProviderEnabled(): Boolean = try {
        lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
    } catch (e: Exception) { false }

    /** 注册全部运动传感器（不需要任何权限） */
    fun startSensors() {
        if (sensorsRunning) return
        val wanted = intArrayOf(
            Sensor.TYPE_LINEAR_ACCELERATION,
            Sensor.TYPE_ACCELEROMETER,
            Sensor.TYPE_GYROSCOPE,
            Sensor.TYPE_ROTATION_VECTOR,
            Sensor.TYPE_GAME_ROTATION_VECTOR,
            Sensor.TYPE_GRAVITY,
            Sensor.TYPE_MAGNETIC_FIELD
        )
        wanted.forEach { type ->
            val s = sm.getDefaultSensor(type)
            if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
            mark(type, s != null)
        }
        sensorsRunning = true
    }

    /** 真正点亮系统 GPS 图标 */
    fun startGps() {
        if (gpsRunning || !hasLocationPermission() || !isGpsProviderEnabled()) return
        try {
            lm.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 200L, 0f, this, Looper.getMainLooper()
            )
            gpsRunning = true
            sensorNames["GPS 定位"] = true
        } catch (e: Exception) {
            sensorNames["GPS 定位"] = false
        }
    }

    fun stopAll() {
        if (sensorsRunning) { sm.unregisterListener(this); sensorsRunning = false }
        if (gpsRunning) {
            try { lm.removeUpdates(this) } catch (e: Exception) { /* ignore */ }
            gpsRunning = false
        }
        for (k in sensorNames.keys.toList()) sensorNames[k] = false
        resetTripState()
    }

    fun resetTripState() {
        aX = 0.0; aY = 0.0; aZ = 0.0; gX = 0.0; gY = 0.0; gZ = 0.0
        oA = null; oB = null; oG = null
        lat = null; lon = null; accM = null; altM = null; bearingDeg = null
        speedKmh = 0.0; gpsFix = 0; gpsOk = false
        aLong = 0.0; aLat = 0.0
        prevV = 0.0; prevT = 0.0; prevBearing = null
    }

    private fun mark(type: Int, ok: Boolean) {
        val key = when (type) {
            Sensor.TYPE_LINEAR_ACCELERATION -> "线性加速度"
            Sensor.TYPE_ACCELEROMETER -> "加速度计"
            Sensor.TYPE_GYROSCOPE -> "陀螺仪"
            Sensor.TYPE_ROTATION_VECTOR, Sensor.TYPE_GAME_ROTATION_VECTOR -> "旋转向量/姿态"
            Sensor.TYPE_GRAVITY -> "重力传感器"
            Sensor.TYPE_MAGNETIC_FIELD -> "地磁传感器"
            else -> return
        }
        if (ok) sensorNames[key] = true
    }

    override fun onSensorChanged(e: SensorEvent) {
        lastSensorAt = System.currentTimeMillis()
        when (e.sensor.type) {
            Sensor.TYPE_LINEAR_ACCELERATION -> {
                aX = e.values[0].toDouble(); aY = e.values[1].toDouble(); aZ = e.values[2].toDouble()
            }
            Sensor.TYPE_ACCELEROMETER -> {
                for (i in 0..2) gravity[i] = gravity[i] * 0.98f + e.values[i] * 0.02f
                aX = (e.values[0] - gravity[0]).toDouble()
                aY = (e.values[1] - gravity[1]).toDouble()
                aZ = (e.values[2] - gravity[2]).toDouble()
            }
            Sensor.TYPE_GYROSCOPE -> {
                gX = Math.toDegrees(e.values[0].toDouble())
                gY = Math.toDegrees(e.values[1].toDouble())
                gZ = Math.toDegrees(e.values[2].toDouble())
            }
            Sensor.TYPE_ROTATION_VECTOR, Sensor.TYPE_GAME_ROTATION_VECTOR -> {
                try {
                    SensorManager.getRotationMatrixFromVector(rotMat, e.values)
                    SensorManager.getOrientation(rotMat, orient)
                    oA = Math.toDegrees(orient[0].toDouble())
                    oB = Math.toDegrees(orient[1].toDouble())
                    oG = Math.toDegrees(orient[2].toDouble())
                } catch (ignored: Exception) { }
            }
        }
        // GPS 还没来时，用加速度计先顶上；GPS 可用后以 GPS 推导为主
        if (!gpsOk) { aLong = aY.coerceIn(-8.0, 8.0); aLat = aX.coerceIn(-8.0, 8.0) }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onLocationChanged(loc: Location) {
        val t = loc.elapsedRealtimeNanos / 1_000_000_000.0
        val v = if (loc.hasSpeed()) loc.speed.toDouble() * 3.6 else speedKmh
        if (prevT > 0.0) {
            val dt = (t - prevT).coerceIn(0.2, 2.0)
            aLong = ((v - prevV) / 3.6 / dt).coerceIn(-8.0, 8.0)
            if (loc.hasBearing() && prevBearing != null) {
                var dh = Math.toRadians(loc.bearing.toDouble() - prevBearing!!)
                if (dh > PI) dh -= 2 * PI
                if (dh < -PI) dh += 2 * PI
                aLat = ((v / 3.6) * dh / dt).coerceIn(-10.0, 10.0)
            }
        }
        prevV = v; prevT = t
        if (loc.hasBearing()) prevBearing = loc.bearing.toDouble()
        lat = loc.latitude; lon = loc.longitude
        accM = if (loc.hasAccuracy()) loc.accuracy else null
        altM = if (loc.hasAltitude()) loc.altitude else null
        bearingDeg = if (loc.hasBearing()) loc.bearing else null
        speedKmh = v; gpsFix++; gpsOk = true
        sensorNames["GPS 定位"] = true
        lastSensorAt = System.currentTimeMillis()
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {
        if (provider == LocationManager.GPS_PROVIDER) { gpsOk = false; sensorNames["GPS 定位"] = false }
    }
}
